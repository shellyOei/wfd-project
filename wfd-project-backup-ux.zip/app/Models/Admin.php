<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model;

class Admin extends Authenticatable
{
    use HasUuids, SoftDeletes;

    protected $fillable = [
        'name',
        'email',
        'password',
        'doctor_id',
    ];

    protected $hidden = [
        'password',
    ];

     protected function casts(): array
    {
        return [
            'password' => 'hashed',
        ];
    }

    public function getAuthPassword()
    {
        return $this->password;
    }

    public function doctor()
    {
        return $this->belongsTo(Doctor::class);
    }

    // for role checking 
    public function isDoctor() : bool
    {
        return $this->doctor()->exists();
    }
}
